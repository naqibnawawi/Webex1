<!DOCTYPE html>
<html>

<head>
    <meta charset="utf8">
    <title>Custom Webex Page</title>
    <link rel="stylesheet" href="https://code.s4d.io/widget-recents/production/main.css">
    <link rel="stylesheet" href="https://code.s4d.io/widget-space/production/main.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="https://code.s4d.io/widget-space/production/bundle.js"></script>
    <script src="https://code.s4d.io/widget-recents/production/bundle.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
   <style>
   html {
         height: 100%;
      }

      body {
         font-family: 'Arial', sans-serif;
         background-color: #f0f0f0; /* Light gray background */
         margin: 0;
         padding: 0;
         display: flex;
         justify-content: center;
         align-items: center;
         min-height: 100vh; /* Minimum 100% of the viewport height */
         background-image: url(pic2.jpg); 
         background-size: cover;
      }

      #access-token-form {
         background-color: black; /* Blue background for the form */
         color: #ffffff; /* White text color */
         padding: 30px;
         text-align: center;
         border-radius: 10px;
      }

      /* Add these styles to your existing CSS */

#access-token-form button {
   background-color: green; 
   color: #ffffff; 
   padding: 10px 20px; 
   font-size: 16px;
   border: none;
   border-radius: 20px; 
   cursor: pointer; 
}

#access-token-form button:hover {
   background-color: #2980b9; /* Darker background color on hover */
}


      #access-token-form label {
         font-size: 18px;
      }

      #access-token {
         width: 300px;
         padding: 10px;
         font-size: 16px;
      }

      #widgets-container {
         display: none;
         padding: 20px;
         text-align: center;
      }

      #recents {
         width: 250px;
         height: 500px;
         float: left;
         background-color: #ffffff; /* White background for the Recents widget */
         border: 1px solid #ddd; /* Light border */
         border-radius: 5px;
         margin-right: 20px;
      }

      #space {
         width: 900px;
         height: 500px;
         background-color: #ffffff; /* White background for the Space widget */
         border: 1px solid #ddd; /* Light border */
         border-radius: 5px;
      }
      #schedule-form {
         background-color: #1f212e;
         color: #ffffff;
         padding: 30px;
         text-align: center;
         border-radius: 40px;
         box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
         margin-top: 20px;
      }

      #schedule-form button {
         background-color: #3498db;
         color: #ffffff;
         padding: 12px 20px;
         font-size: 15px;
         border: none;
         border-radius: 5px;
         cursor: pointer;
         transition: background-color 0.3s ease;
         margin-top: 15px;
      }

      #schedule-form button:hover {
         background-color: #2980b9;
      }
              /* New styles for participant management buttons */
              .participant-control-btn {
            background-color: #3498db;
            color: #ffffff;
            padding: 8px 12px;
            font-size: 14px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
            margin: 5px;
        }

        /* New styles for integration button */
        #integration-btn {
            background-color: #27ae60;
            color: #ffffff;
            padding: 12px 20px;
            font-size: 18px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            margin-top: 15px;
        }

        #integration-btn:hover {
            background-color: #219653;
        }
   </style>
</head>

<body>
    <!-- Access Token Input Form -->
    <div id="access-token-form">
      <label for="access-token">Enter Webex Teams Access Token:</label>
      <br>
      <input type="text" id="access-token" placeholder="Paste your token here">
      <br>
      <button onclick="setAccessToken()">Submit</button>
  </div>

  <!-- Recents and Space Widgets -->
  <div id="widgets-container">
      <div id="recents"></div>
      <div id="space"></div>
      <!-- Participant Management Buttons -->
      <button class="participant-control-btn" onclick="muteParticipant()">Mute Participant</button>
      <button class="participant-control-btn" onclick="unmuteParticipant()">Unmute Participant</button>
      <button class="participant-control-btn" onclick="controlVideo()">Control Video</button>
      <button class="participant-control-btn" onclick="removeParticipant()">Remove Participant</button>
      <!-- Schedule Meeting Form -->
      <div id="schedule-form" style="display: none;">
          <label for="meeting-topic">Meeting Topic:</label>
          <br>
          <input type="text" id="meeting-topic" placeholder="Enter meeting topic">
          <br>
          <label for="meeting-date">Meeting Date:</label>
          <br>
          <input type="date" id="meeting-date">
          <br>
          <label for="meeting-time">Meeting Time:</label>
          <br>
          <input type="time" id="meeting-time">
          <br>
          <label for="participants">Participants (comma-separated emails):</label>
          <br>
          <input type="text" id="participants" placeholder="Enter participant emails">
          <br>
          <button onclick="scheduleMeeting(event)">Schedule Meeting</button>
      </div>
      <!-- Integration Button -->
      <button id="integration-btn" onclick="integrateWithExternalTool()">Integrate with External Tool</button>
  </div>


<script>

let isMeetingActive = false;

function setAccessToken() {
    const accessTokenInput = document.getElementById('access-token');
    const token = accessTokenInput.value.trim();

    if (token) {
        hideAccessTokenForm();
        initializeWidgets(token);
        showScheduleForm(); // Show the schedule form after successful authentication
    } else {
        toastr.error('Please enter a valid access token.');
    }

    webex.meetings.on('meeting:added', () => {
                isMeetingActive = true;
                updateParticipantButtonsVisibility();
            });

            webex.meetings.on('meeting:removed', () => {
                isMeetingActive = false;
                updateParticipantButtonsVisibility();
            });
}
function updateParticipantButtonsVisibility() {
            const participantButtons = document.querySelectorAll('.participant-control-btn');
            const scheduleForm = document.getElementById('schedule-form');
            const integrationBtn = document.getElementById('integration-btn');

            if (isMeetingActive) {
                // Show participant management buttons
                participantButtons.forEach(button => button.style.display = 'inline-block');

                // Hide or show other elements based on your requirements
                scheduleForm.style.display = 'none';
                integrationBtn.style.display = 'none';
            } else {
                // Hide participant management buttons
                participantButtons.forEach(button => button.style.display = 'none');

                // Show or hide other elements based on your requirements
                scheduleForm.style.display = 'block';
                integrationBtn.style.display = 'block';
            }
        }

function showScheduleForm() {
    const scheduleForm = document.getElementById('schedule-form');
    scheduleForm.style.display = 'block';
}

      function hideAccessTokenForm() {
         const accessTokenForm = document.getElementById('access-token-form');
         accessTokenForm.style.display = 'none';

         const widgetsContainer = document.getElementById('widgets-container');
         widgetsContainer.style.display = 'block';
      }

      function initializeWidgets(token) {
         // Init the Recents widget
         const recentsElement = document.getElementById('recents');
         webex.widget(recentsElement).recentsWidget({
            accessToken: token,
            onEvent: callback
         });

         function callback(type, event) {
            if (type !== "rooms:selected") {
               console.log("new event: " + type);
               toastr.info('Event Received', type);
               return;
            }

            let selectedRoom = event.data.id;
            console.log("room " + selectedRoom + " was selected");

            let spaceElement = document.getElementById('space');

            // Remove existing 'Space' widget (if any)
            try {
               webex.widget(spaceElement).remove().then(function (removed) {
                  if (removed) {
                     console.log('removed!');
                  }
               });
            } catch (err) {
               console.error('could not remove Space widget :-(, continuing...');
            }

            // Inject a new 'Space' widget with the selected room
            webex.widget(spaceElement).spaceWidget({
               accessToken: token,
               destinationType: "spaceId",
               destinationId: selectedRoom,
               activities: { "files": true, "meet": true, "message": true, "people": true },
               initialActivity: 'message',
               secondaryActivitiesFullWidth: false
            });
         }
      }
      function showScheduleForm() {
         const scheduleForm = document.getElementById('schedule-form');
         scheduleForm.style.display = 'block';
      }
      function muteParticipant() {
            // Implement logic to mute the selected participant
            toastr.info('Participant Muted');
        }

        function unmuteParticipant() {
            // Implement logic to unmute the selected participant
            toastr.info('Participant Unmuted');
        }

        function controlVideo() {
            // Implement logic to control video for the selected participant
            toastr.info('Video Controlled');
        }

        function removeParticipant() {
            // Implement logic to remove the selected participant
            toastr.warning('Participant Removed');
        }

// Enhanced schedule meeting function
function scheduleMeeting(event) {
    event.preventDefault(); // Prevent the form from being submitted

    const meetingTopicInput = document.getElementById('meeting-topic');
    const meetingTopic = meetingTopicInput.value.trim();
    const meetingDateInput = document.getElementById('meeting-date');
    const meetingDate = meetingDateInput.value;
    const meetingTimeInput = document.getElementById('meeting-time');
    const meetingTime = meetingTimeInput.value;
    const participantsInput = document.getElementById('participants');
    const participants = participantsInput.value.trim();

    if (meetingTopic && meetingDate && meetingTime && participants) {
        // Call your server-side logic to create a Webex meeting and obtain meeting details
        // This will typically involve making a request to the Webex Meetings API from your server
        // The server should return the meeting link and other details

        const meetingLink = "https://meet346.webex.com/meet/pr26404568453";
        const meetingDetails = `Meeting Topic: ${meetingTopic}\nDate: ${meetingDate}\nTime: ${meetingTime}\nMeeting Link: ${meetingLink}`;

        // Display meeting details to the user
        toastr.success('Meeting Scheduled', meetingDetails);

        // Copy the real meeting link to the clipboard
        copyToClipboard(meetingLink);
    } else {
        toastr.error('Please fill in all the meeting details.');
    }
}

        // Integration function
        function integrateWithExternalTool() {
            // Implement logic to interact with external tool or API
            // This could involve making AJAX requests or other methods to integrate with external services
            toastr.info('Integration with External Tool initiated.');
        }

        function copyToClipboard(text) {
            const textarea = document.createElement('textarea');
            textarea.value = text;
            document.body.appendChild(textarea);
            textarea.select();
            document.execCommand('copy');
            document.body.removeChild(textarea);
        }

        updateParticipantButtonsVisibility();
    </script>

</body>

</html>